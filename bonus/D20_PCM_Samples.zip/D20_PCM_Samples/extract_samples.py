#!/usr/bin/env python3
"""Decode user-supplied Roland D-20 ROMs. Python standard library only."""
from pathlib import Path
import argparse,hashlib,json,math,struct,wave,csv

def decode(raw):
    result=[]
    for hi,lo in zip(raw[::2],raw[1::2]):
        r=(hi<<8)|lo
        o=(r&0x8000)|((r<<8)&0x4000)|((r>>1)&0x3f80)|((r<<1)&0x7e)|((r>>7)&1)
        inv=(o&0x8000)|((o&0x4000)>>8)|((o&0x3f80)<<1)|((o&0x7e)>>1)|((o&1)<<7)
        assert inv==r
        amp=2**(((o&32767)-32787)/2048)
        assert round(2048*math.log2(amp)+32787)==(o&32767)
        result.append(round((-amp if o&32768 else amp)*32767))
    return result

def main():
    a=argparse.ArgumentParser();a.add_argument('rom_dir',type=Path);a.add_argument('--output',type=Path,default=Path(__file__).parent);args=a.parse_args()
    names=json.loads(Path(__file__).with_name('pcm_names.json').read_text());assert len(names)==256
    byhash={hashlib.md5(f.read_bytes()).hexdigest():f for f in args.rom_dir.glob('*.BIN')}
    # Content identity is essential: supplied filename labels are reversed.
    sources=[byhash[h] for h in ['61ad8efa5e78c19be691b2b2e2ddda4b','ba6fa6a8f9892dacd6009f52225ac2a2']]
    raw=b''.join(p.read_bytes() for p in sources);assert len(raw)==1048576
    tone=byhash['d6896234d000f4f155040e6968a0a5ec'].read_bytes()
    decoded=decode(raw); rows=[]
    for i,name in enumerate(names):
        pos,flags,lo,hi=tone[0x900+4*i:0x904+4*i]
        start=pos*2048;n=2048<<((flags&112)>>4);assert start+n<=len(decoded)
        samples=decoded[start:start+n];bank=i//128+1;num=i%128+1
        safe=name.replace('*','_FixedTune').replace(' ','_')
        filename=f'PCM_{i+1:03d}_B{bank}_{num:03d}_{safe}.wav'
        path=args.output/f'Bank_{bank}'/filename;path.parent.mkdir(parents=True,exist_ok=True)
        audio=struct.pack('<'+'h'*n,*samples)
        with wave.open(str(path),'wb') as w:
            w.setparams((1,2,32000,0,'NONE','not compressed'));w.writeframes(audio)
        with wave.open(str(path),'rb') as w:
            assert w.getparams()[:3]==(1,2,32000) and w.getnframes()==n
            assert w.readframes(n)==audio
        rows.append(dict(pcm_number=i+1,bank=bank,bank_number=num,name=name,filename=str(path.relative_to(args.output)),tone_table_offset=hex(0x900+4*i),combined_pcm_byte_offset=hex(start*2),frames=n,duration_at_32000=n/32000,loop=bool(flags&128),flags=hex(flags),pitch_word=hex((hi<<8)|lo),wav_sha256=hashlib.sha256(path.read_bytes()).hexdigest()))
    with (args.output/'sample_manifest.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=rows[0]);w.writeheader();w.writerows(rows)
    provenance={'pcm_order':[{'file':p.name,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sources],'tone_rom_sha256':hashlib.sha256(tone).hexdigest(),'table_offset':'0x900','table_entries':256,'unique_address_length_pairs':len(set((r['combined_pcm_byte_offset'],r['frames']) for r in rows)),'decoded_sample_words':len(decoded),'export_sample_rate':32000,'sample_rate_status':'Preview rate, original note/pitch not reconstructed','sources':['https://github.com/munt/munt/blob/master/mt32emu/src/Synth.cpp','https://github.com/munt/munt/blob/master/mt32emu/src/LA32FloatWaveGenerator.cpp','https://github.com/luginf/Di-111-synth/blob/main/munt/mt32emu/src/Synth.cpp','https://github.com/luginf/Di-111-synth/blob/main/plugin/Source/PluginEditor.cpp','https://cdn.roland.com/assets/media/pdf/D-20_OM.pdf']}
    (args.output/'provenance.json').write_text(json.dumps(provenance,indent=2)+'\n')
    print(json.dumps({'wav_files':len(rows),'unique_regions':provenance['unique_address_length_pairs'],'looped_entries':sum(r['loop'] for r in rows),'all_wavs_verified':True}))
if __name__=='__main__':main()
