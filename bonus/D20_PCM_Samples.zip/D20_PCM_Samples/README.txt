D-20 PCM ROM extraction
======================
256 selection-indexed WAVs, grouped into two banks of 128.
Format: 32,000 Hz, mono, signed 16-bit PCM, no normalization or added effects.

Naming
------
PCM_001_B1_001_Bass_Drum-1.wav means overall selection 1, bank 1, entry 1.
Names were cross-checked visually against Roland D-20 Owner's Manual PDF pages
167-168 (PCM Sounds, Bank 1 and Bank 2). Initial transcription came from Di-111;
Draw bars and Telephone Bell (Loop) were corrected against the D-20 chart.
An asterisk in the source name is written as _FixedTune in filenames. It marks
alternate drum selections whose tuning behaviour differs; their WAV bytes repeat.
Loop-N and Jam-N are the listed names, not unidentified samples.

Interpretation and limits
-------------------------
These are decoded raw waveform regions, NOT rendered D-20 tones or patches.
32 kHz is a preview/export rate. Native note pitch, master tuning, envelopes,
filtering, interpolation, output circuitry and reverb are not reconstructed.
Looped samples are exported once through the selected region; no automatic WAV
loop metadata is added. The loop flag and raw pitch word are in sample_manifest.csv.
Different entries can reuse a region, change loop/tuning flags, or span neighbouring
waveforms deliberately. There are 168 unique address/length regions, not 256
independent recordings. Source PCM regions can overlap.

Validation
----------
Used tone ROM table at 0x900: 256 four-byte records. All ranges are within the
combined PCM ROM. Start = record[0]*2048 sample words; length =
2048 << ((record[1]&0x70)>>4). All 524,288 decoded sample words passed inverse
bit-order and log-magnitude checks before output quantization. Every WAV was
reopened and checked for frame count, mono/16-bit/32k format and exact audio bytes.
Table interpretation is supported by a related D-110 implementation and agreement
with the named loop/drum entries; it has not been confirmed against D-20 playback.

Source identities
-----------------
The provided PCM filenames appear reversed compared with reference content hashes.
Bank order was chosen by content, not filename:
1. r15179878-3.BIN (MD5 61ad8efa5e78c19be691b2b2e2ddda4b)
2. r15179880-3.BIN (MD5 ba6fa6a8f9892dacd6009f52225ac2a2)
Tone metadata: r15179904-00-lh5310dj-full-3.BIN.
See provenance.json and sample_manifest.csv for hashes, offsets and source links.
The original ROM files were not modified and are not included in this archive.

Reproduce
---------
python3 extract_samples.py '/path/to/Roland D-20 ROMS (w-o control)' --output '/path/to/output'
Requires Python 3 standard library and the three original ROM images.

Copyright and usage
-------------------
Roland D-20 PCM samples — copyright and usage notice
===================================================
The original PCM waveform content is copyright Roland Corporation.
These extracted samples are shared for experimentation and non-commercial use only.
They are excluded from this project's MIT licence. All rights in the original
waveform content remain with Roland Corporation. This notice does not claim
that Roland Corporation has granted a redistribution or other licence.
This is an independent project, not affiliated with or endorsed by Roland Corporation.

Origin
------
Extracted from the supplied dump set named Roland D-20 ROMS (w-o control).
The two PCM ROM images contain factory waveform data; the tone ROM supplies
selection boundaries and flags. These are not control firmware or recordings
of complete synthesizer patches. Source filenames and content hashes are above
and in provenance.json.
